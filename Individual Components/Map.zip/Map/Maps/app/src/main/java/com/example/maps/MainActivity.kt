package com.example.maps

import android.Manifest
import android.content.Intent
import android.content.IntentSender
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.LocationRequest
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import androidx.appcompat.app.AppCompatCallback
import androidx.core.app.ActivityCompat
import com.example.maps.databinding.ActivityMainBinding
import com.example.maps.databinding.ActivityMapsBinding
import com.google.android.gms.common.api.ApiException
import com.google.android.gms.common.api.ResolvableApiException
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
//import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationSettingsRequest
import com.google.android.gms.location.LocationSettingsStatusCodes
import java.io.IOException
import java.util.*

class MainActivity : AppCompatActivity() {
    lateinit var binding: ActivityMainBinding
    lateinit var locationRequest: LocationRequest
    lateinit var fusedLocationProviderClient: FusedLocationProviderClient
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this)
        binding.getLocation.setOnClickListener(){
            //step 1 check self permission
            checkLocationPermission()

        }

    }



    private fun checkLocationPermission() {
        if(ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION)
            == PackageManager.PERMISSION_GRANTED){
            //when permission is already grant
            checkGPS()

        }else{
            //when permission is denied
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                100)
        }

    }

    fun createLocationRequest() {
         locationRequest = LocationRequest.create()?.apply {
            interval = 10000
            fastestInterval = 5000
            priority = LocationRequest.PRIORITY_HIGH_ACCURACY
        }

    }

    private fun checkGPS(){
        createLocationRequest()


        val builder = LocationSettingsRequest.Builder()
            .addLocationRequest(locationRequest)

        builder.setAlwaysShow(true)

        val result = LocationServices.getSettingsClient(this.applicationContext)
            .checkLocationSettings(builder.build())



        result.addOnCompleteListener { task ->

            try {
                // when the GPS is on
                val response = task.getResult(
                    ApiException::class.java
                )
                getUserLocation()

            }catch(e : ApiException){
                // when the GPS is off
                e.printStackTrace()

                when(e.statusCode){
                    LocationSettingsStatusCodes.RESOLUTION_REQUIRED -> try{
                        //here we send the request to enable the GPS
                        val resolveApiException = e as ResolvableApiException
                        resolveApiException.startResolutionForResult(this,200)
                    }catch(sendIntentExpcetion: IntentSender.SendIntentException) {
                    }
                        LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE -> {
                            // when the setting is unavailable

                        }

                }

            }

        }

    }

    private fun getUserLocation() {

        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
        ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
        ) != PackageManager.PERMISSION_GRANTED


        ){
            //consider calling ActivityCompat.requestPermissions
            return
        }

        fusedLocationProviderClient.lastLocation.addOnCompleteListener{task ->

            val location = task.getResult()

            if(location != null){

                try {
                    val geocoder = Geocoder(this, Locale.getDefault())
                    val address = geocoder.getFromLocation(location.latitude, location.longitude,1)

                    //here we set the address in text view

                    val address_line = address[0].getAddressLine(0)
                    binding.locationText.setText(address_line)

                    val address_location = address[0].getAddressLine(0)

                    openLocation(address_location.toString())

                }catch (e : IOException) {

                }

            }
        }
    }

    private fun openLocation(location: String) {

        //here we open this location from google map

        //lets set on button click
        binding.locationText.setOnClickListener {
            if(binding.locationText.text.isEmpty()){
                //when the location is not empty
                val uri = Uri.parse( "geo: 0, #?q=$location")
                val intent = Intent(Intent.ACTION_VIEW,uri)
                intent.setPackage("com.google.android.apps.maps")
                startActivity(intent)
            }
        }

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if(requestCode == 200){
            if(resultCode == RESULT_OK){
                //when user allowed GPS request
                var handler = Handler()
                var runnable = Runnable{
                    getUserLocation()
                }

            }

        }

    }

}